package DESIGN;

public class Player {
    private int health;
    private int strength;
    private int attack;

    public Player(int health, int strength, int attack) {
        this.health = health;
        this.strength = strength;
        this.attack = attack;
    }

    public int getHealth() {
        return health;
    }

    public void takeDamage(int damage) {
        health -= damage;
    }

    public int attack(int attackRoll, int defenseRoll) {
        int attackDamage = attack * attackRoll;
        int defense = strength * defenseRoll;
        return Math.max(0, attackDamage - defense);
    }

    public boolean isAlive() {
        return health > 0;
    }
}