package DESIGN;

import java.util.Random;

public class Arena {
    private Player player1;
    private Player player2;

    public Arena(Player player1, Player player2) {
        this.player1 = player1;
        this.player2 = player2;
    }

    public void fight() {
        Random random = new Random();
        Player attacker = player1.getHealth() < player2.getHealth() ? player1 : player2;
        Player defender = attacker == player1 ? player2 : player1;

        while (player1.isAlive() && player2.isAlive()) {
            int attackRoll = random.nextInt(6) + 1;
            int defenseRoll = random.nextInt(6) + 1;

            int damage = attacker.attack(attackRoll, defenseRoll);
            defender.takeDamage(damage);

            // Swap attacker and defender for the next round
            Player temp = attacker;
            attacker = defender;
            defender = temp;
        }

        // Print the winner's name
        if (player1.isAlive()) {
            System.out.println("Player 1 wins!");
        } else {
            System.out.println("Player 2 wins!");
        }
    }
}
